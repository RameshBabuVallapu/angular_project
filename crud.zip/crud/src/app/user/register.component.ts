import { FormControl, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
// import {  FileUploader, FileSelectDirective } from 'ng2-file-upload/ng2-file-upload';
const URL = 'http://localhost:3000/users/';

@Component({
    selector: 'register',
    templateUrl: 'register.component.html',
    styleUrls:['register.component.css'],
  
})

export class RegisterComponent implements OnInit {
  form=new FormGroup({
    firstName:new FormControl('',Validators.required),
    lastName:new FormControl('',Validators.required),
    userName:new FormControl('',Validators.required),
    password:new FormControl('',[Validators.minLength(6),Validators.required]),
    email:new FormControl('',[Validators.required,Validators.email])
  })
    // public uploader: FileUploader = new FileUploader({url: URL, itemAlias: 'files'});
  errors: any[] = [];
    user:User = new User();
    selectedFiles: FileList;
    currentFileUpload: File;
    constructor(private us:UserService,private router:Router) { }
    selectFile(event) {
      this.selectedFiles = event.target.files;
    }
    save() {
        this.us.insertStudent(this.user).subscribe(
          () => {
            this.router.navigate(['/login']);
            alert("successfully registered")
          },
          (errorResponse) => {
            this.errors = errorResponse.error.errors;
           alert("failed to registerd");
          })
        }
          // upload(){
          //   this.uploader.onAfterAddingFile = (file) => { file.withCredentials = false; };
          //   this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
          //   console.log('ImageUpload:uploaded:');       
          //     alert('File uploaded successfully');
          //   };
          // }
  ngOnInit(){}
}