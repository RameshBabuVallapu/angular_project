import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { StudentFormComponent } from './student-form.component';
@Injectable()
export class ProtectDataGuard implements CanDeactivate<StudentFormComponent> {
    canDeactivate(
        component: StudentFormComponent,
        currentRoute: ActivatedRouteSnapshot, 
        currentState: RouterStateSnapshot
    ): Observable<boolean>|Promise<boolean>|boolean {

        if(component.currentForm.dirty){
            var result = confirm("do you want to discard changes?");
            return result;
        }
        return true;
    }
}