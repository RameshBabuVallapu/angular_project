import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ChangePasswordComponent } from './change-password.component';
import { LoginComponent } from './login.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RegisterComponent } from './register.component';
import { NgxSpinnerModule } from 'ngx-spinner';

var userRoutes = [
    {path:"login",component:LoginComponent},
    {path:"changePWD",component:ChangePasswordComponent},
    {path:"regis",component:RegisterComponent},
    {path:"",redirectTo:"login",pathMatch:'full'},
]


@NgModule({
    imports: [CommonModule,NgxSpinnerModule,HttpClientModule,FormsModule,RouterModule.forChild(userRoutes),ReactiveFormsModule],
    declarations:[LoginComponent,ChangePasswordComponent,RegisterComponent],
    providers:[UserService]
    
})
export class UserModule { }
