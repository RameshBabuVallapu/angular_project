export class User{
    id:number;
    userName:string;
    password:string;
    firstName:string;
    lastName:string;
    email:string;
    role:string;
    fileupload:File;
}