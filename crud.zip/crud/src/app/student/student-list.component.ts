import { StudentService } from './student.service';
import { Student } from './student';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'student-list',
    templateUrl: 'student-list.component.html',
    styleUrls:['student-list.component.css']
})

export class StudentListComponent implements OnInit {

    students:Student[]

    constructor(private ss:StudentService) {
        this.ss.getAllStudents().subscribe((data)=>{
            this.students = <Student[]>data;
        })
     }

    ngOnInit() { }
}