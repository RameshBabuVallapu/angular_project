import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class SecurityGuard implements CanActivate {
    constructor() { }

    canActivate() {

        var userName = localStorage.getItem("userName");

        if(userName){
            return true;
        }

        return false;
    }
}