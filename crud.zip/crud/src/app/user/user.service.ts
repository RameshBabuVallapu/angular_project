import { User } from './user';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class UserService {

    constructor(private hc:HttpClient) { }
    // username and password
    login(user:User){
        return this.hc.get("http://localhost:3000/users?userName="+user.userName+"&password="+user.password)
    }
    insertStudent(user:User){
        return this.hc.post("http://localhost:3000/users/",user);
    }
    
}
