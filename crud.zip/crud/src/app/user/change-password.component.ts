import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'change-password',
    templateUrl: 'change-password.component.html'
})

export class ChangePasswordComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}