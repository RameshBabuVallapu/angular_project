import { UserModule } from './user/user.module';
import { StudentModule } from './student/student.module';
import { AboutComponent } from './about.component';
import { ContactComponent } from './contact.component';
import { HomeComponent } from './home.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule,Routes, RouterLink } from "@angular/router";
import { AppComponent } from './app.component';
import { SecurityGuard } from './shared/security.guard';
import { RegisterComponent } from './user/register.component';
import { NgxSpinnerModule } from 'ngx-spinner';

var routes:Routes=[
    {path:"home",component:HomeComponent ,canActivate:[SecurityGuard]},
    {path:"contact",component:ContactComponent,canActivate:[SecurityGuard]},
    {path:"about",component:AboutComponent,canActivate:[SecurityGuard]},
   
    {path:"",redirectTo:"login",pathMatch:'full'},

]


@NgModule({
    imports: [BrowserModule,NgxSpinnerModule,StudentModule,UserModule,RouterModule.forRoot(routes),RouterModule,],
    declarations: [AppComponent,HomeComponent,ContactComponent,AboutComponent,],
    bootstrap: [AppComponent],
})
export class AppModule { }
