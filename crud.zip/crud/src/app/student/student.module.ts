import { UniqueDirective } from './../shared/unique.directive';
import { ProtectDataGuard } from './protectdata.guard';
import { AutzGuard } from './../shared/autz.guard';
import { SecurityGuard } from './../shared/security.guard';
import { StudentService } from './student.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { StudentFormComponent } from './student-form.component';
import { StudentListComponent } from './student-list.component';
import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';
import { FormsModule } from "@angular/forms";
var studentRoutes = [
    {path:"studentList",component:StudentListComponent,canActivate:[SecurityGuard]},    
    {path:"studentForm",component:StudentFormComponent,canActivate:[SecurityGuard,AutzGuard]}
]

@NgModule({
    imports: [ MatDatepickerModule,
        MatInputModule,
        MatNativeDateModule,CommonModule,HttpClientModule,FormsModule,RouterModule.forChild(studentRoutes)],
    declarations:[StudentListComponent,StudentFormComponent,UniqueDirective],
    providers:[StudentService,SecurityGuard,AutzGuard,ProtectDataGuard]
})
export class StudentModule { 
}