import { StudentService } from './../student/student.service';
import { Student } from './../student/student';

import { Directive, HostListener, Input, ElementRef } from '@angular/core';

@Directive({ selector: '[unique]' })
export class UniqueDirective {

    constructor(private e1:ElementRef,private ss:StudentService) { }

    @HostListener("keyup")
    m1(){
        var currentValue = this.e1.nativeElement.value;
        this.ss.getStudentById(currentValue).subscribe((data)=>{
            var student = <Student>data;
            if(student)
                alert("already taken");
        },(error)=>{
                alert("valid");       
        });
    }
}