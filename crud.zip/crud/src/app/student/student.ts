export class Student{
    id:number;
    name:string;
    email:string;
    altemail:string;
    mob:number;
    altmob:number;
    role:string;
    dob:string;
    gender:string;
    file:File;
}