import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { User } from './user';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
    selector: 'login',
    templateUrl: 'login.component.html',
    styleUrls:['login.component.css','animate.css']
})

export class LoginComponent implements OnInit {
    user:User = new User();
    form =new FormGroup({
         userName:new FormControl('',Validators.required),
         password:new FormControl('',[Validators.required,Validators.minLength(6)])

    })
    constructor(private us:UserService,private router:Router,private spinner:NgxSpinnerService) { }


   

    login(){
        this.us.login(this.user).subscribe((data)=>{
            var users = <User[]>data;
            if(users.length>0){
                localStorage.setItem("userName",users[0].userName);
                localStorage.setItem("role",users[0].role);
                alert("succesfully loged in");
                this.openspinner();
                this.router.navigate(["/home"]);
            
            }
            else
            alert("invalid credentials");
        },
        )
    }
    openspinner(){
        this.spinner.show();
        setTimeout(()=>{
            this.spinner.hide();
        },500);
    }
    ngOnInit() { 
        this.openspinner();
        
        }
}