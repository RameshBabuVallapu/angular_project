import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AutzGuard implements CanActivate {
    constructor() { }

    canActivate() {

        var role = localStorage.getItem("role");

        if(role){
            if(role=="admin")
                return true;
        }

        return false;
    }
}