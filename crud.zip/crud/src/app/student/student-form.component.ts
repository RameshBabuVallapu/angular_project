import { HttpClient, HttpEventType } from '@angular/common/http';
import { LoginComponent } from './../user/login.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentService } from './student.service';
import { Student } from './student';
import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'student-form',
    templateUrl: 'student-form.component.html',
    styleUrls:['student-form.component.css']
})

export class StudentFormComponent implements OnInit {
    form=new FormGroup({
    id:new FormControl('',[Validators.required,Validators.maxLength(10)]),
    name:new FormControl('',Validators.required),
    email:new FormControl('',[Validators.required,Validators.email]),
    altemail:new FormControl('',[Validators.required,Validators.email]),
    mob:new FormControl('',[Validators.required,Validators.maxLength(10)]),
    altmob:new FormControl('',[Validators.required,Validators.maxLength(10)])

    })
    s1:Student=new Student();

    currentForm;

    constructor(private ss:StudentService,private router:Router, private http:HttpClient ) { }
    images:any=[];
    allfiles:any=[];
    ngOnInit() { }

    save(){
        this.ss.insertStudent(this.s1).subscribe((data)=>{
            alert("success");
            this.router.navigate(['/studentList']);
        })
    }
    
    

    m1(formObj){
        this.currentForm = formObj;
    }

    selectedFile:File=null;
    onFileSelected(event){
    this.selectedFile=<File>event.target.files[0];
    }
    onUpload(){
    const fd=new FormData();
    fd.append('image',this.selectedFile,this.selectedFile.name);
    this.ss.uploaddata(this.s1).subscribe(res=>{
      //  if(event.type==HttpEventType.UploadProgress){
    //if(event.type==HttpEventType.UploadProgress){
   // console.log('Upload Progress:'+Math.round(event.loaded/event).total*100+'%');
  //  }
    console.log(res); 
    });
    }
    

    // fileuploads(event){
    //     const files=event.target.files;
    //     console.log(files);
    //     if(files){
    //         for(let i=0;i<files.length;i++){
    //             const image={
    //                 name:'',
    //                 type:'',
    //                 size:'',
    //                 url:''
    //             };
    //             this.allfiles.push(files[i]);
    //             image.name=files[i].name;
    //             image.type=files[i].type;
    //             image.size=files[i].size;
    //             const reader=new FileReader();
    //             reader.onload=(filedata)=>{
    //                 image.url=reader.result +'';
    //             };
    //             reader.readAsDataURL(files[i]);
    //         }

    //     }
    //     event.srcElement.value=null;
    // }
}